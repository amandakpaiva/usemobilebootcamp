/*
 1)

import SwiftUI

class Person {
    private let name: String
    private let ayear: Int
    private let height: Float
    
    init(name: String, ayear: Int, height: Float) {
        self.name = name
        self.ayear = ayear
        self.height = height
    }
    
    func calculateAge() -> Int {
        let year = Calendar.current.component(.year, from: Date())
        let age = year - ayear
        return age
    }
    
    func takeMed() {
        print("\(name) precisa tomar 2 remédios diariamente.")
    }
}


let pedro = Person(name: "Pedro", ayear: 1981, height: 1.78)
print(pedro.calculateAge())
pedro.takeMed()

 /******/
2)

class Oldman: Person {
     override func takeMed() {
         print("Idosos precisam tomar 3 remédios diariamente.")
     }
 }

 /*
  
  
3.
  
var numbers:[Double] = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

func average(nums: [Double]) -> Double {

    var total = 0.0
    for numbers in nums{
        total += Double(numbers)
    }

    let numbersTotal = Double(nums.count)
    let average = total/numbersTotal
    return average
}

var theAverage = average(nums: numbers)


  /*/*

4.

class MyViewController: UIViewController {
    let contentView: UIView = {
        let view = UIView()
        view.backgroundColor = .yellow
        return view
    }()


    override func viewDidLoad() {
        super.viewDidLoad()
        print("viewDidLoad - ")
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        print("viewWillAppear - MyViewController")
    }
    
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        print("viewWillDisappear - MyViewController")
    }

     
     /*
6)

func m4() -> [Int] {
    var multiplos = [Int]()
    
    for num in 4...50 {
        if num % 4 == 0 {
            multiplos.append(num)
        }
    }
    
    return multiplos
}


print(m4())


      /*/*/*

7.

var people = ["Gustavo", "Breno", "Filipe", "Leo", "Leonardo", "Rogério", "Junior", "Gabriela"]
              
let sortedPeople = people.sorted()
people.sort()
print(people)

           /*/*
              
8.

import SwiftUI

struct ContentView: View {
    
  
var name : String = ""
var zipCode : String = ""
var PublicPlace: String = ""
var houseNumber : String = ""
var district : String = ""
var comp: String = ""
var city : String = ""
var state : String = ""


    var body: some View {
        NavigationView{
            Form{
                    TextField("Nome", text: $name)
                    TextField("CEP", text: $zipCode)
                    TextField("Logradouro", text: $PublicPlace)
                    TextField("Número", text: $houseNumber)
                    TextField("Bairro", text: $district)
                    TextField("Complemento", text: $comp)
                    TextField("Cidade", text: $city)
                    TextField("Estado", text: $state)
                    
                    
                    
                }
             
   print(name, zipCode, PublicPlace, houseNumber,district, comp, city, state)
                })

              
              
              /*/*/*
